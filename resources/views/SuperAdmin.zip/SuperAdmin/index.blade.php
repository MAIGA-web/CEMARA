@extends('layout.header')
@section('contenu')

{{-- On a retiré le bloc <style> qui masquait #left-panel --}}

<div class="content">
    <div class="animated fadeIn">
        <div class="row">

            <!-- BLOC GAUCHE : LISTE DES FERMES -->
            <div class="col-md-8">
                <div class="card shadow">
                    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                        <strong class="card-title mb-0">Gestion des Fermes</strong>
                        <a href="{{ route('fermes.save') }}" class="btn btn-sm btn-light float-right">
                            <i class="fa fa-plus"></i> Nouvelle Ferme
                        </a>
                    </div>
                    <div class="card-body">
                        <table class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th>N°</th>
                                    <th>Nom</th>
                                    <th>Localisation</th>
                                    <th>Email</th>
                                    <th>Tel</th>
                                    <th>État</th>
                                    <th>Date création</th>
                                    <th>Logo</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($fermes as $key => $ferme)
                                    <tr>
                                        <td>{{ $key + 1 }}</td>
                                        <td>{{ $ferme->fer_nom }}</td>
                                        <td>{{ $ferme->fer_adresse }}</td>
                                        <td>{{ $ferme->fer_email }}</td>
                                        <td>{{ $ferme->fer_telephone }}</td>
                                        <td>
                                            @if ($ferme->fer_etat == 0)
                                                <span class="badge badge-success">Opérationnel</span>
                                            @else   
                                                <span class="badge badge-danger">Suspendu</span>
                                            @endif
                                        </td>
                                        <td>{{ $ferme->created_at }}</td>
                                        <td>
                                            @if($ferme->fer_logo)
                                                <img src="{{ asset('storage/' . $ferme->fer_logo) }}" alt="Logo" width="50">
                                            @endif
                                        </td>
                                        <td>
                                            <a href="{{ route('fermes.save', $ferme->id) }}" class="btn btn-sm btn-info">
                                                <i class="fa fa-pencil"></i>
                                            </a>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- BLOC DROITE : SÉLECTION DE FERME -->
            <div class="col-md-4">
                <div class="card border border-primary">
                    <div class="card-header bg-light">
                        <strong class="card-title">Choisir une ferme à administrer</strong>
                    </div>
                    <div class="card-body">
                        <p class="text-muted small">Sélectionnez l'établissement pour charger son dashboard :</p>
                        <form action="{{ route('superadmin.choisir') }}" method="POST">
                            @csrf
                            <div class="form-group">
                                <select name="fer_id" class="form-control border-primary" onchange="this.form.submit()">
                                    <option value="">-- Sélectionner une ferme --</option>
                                    @foreach ($fermes as $ferme)
                                        <option value="{{ $ferme->id }}" {{ session('fer_id') == $ferme->id ? 'selected' : '' }}>
                                            {{ $ferme->fer_nom }}
                                        </option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="mt-3">
                                <small class="text-info">
                                    <i class="fa fa-info-circle"></i> Le choix de la ferme chargera les données correspondantes.
                                </small>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Bouton Déconnexion -->
                <div class="text-center mt-4">
                    <form action="{{ route('logout') }}" method="POST">
                        @csrf
                        <button type="submit" class="btn btn-outline-danger btn-block">
                            <i class="fa fa-power-off"></i> Déconnexion
                        </button>
                    </form>
                </div>

            </div>
        </div>
    </div>
</div>
@endsection